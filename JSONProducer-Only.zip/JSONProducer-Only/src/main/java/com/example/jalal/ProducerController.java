package com.example.jalal;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/kafka/publish")
public class ProducerController {

    @Autowired
    private KafkaTemplate<String, User> kafkaTemplate;
    private static final String JSON_TOPIC = "jsontest";
    
    @Autowired
    private KafkaTemplate<String,String> stringKafkaTemplate;
    private static final String STRING_TOPIC="stringtest";

    @PostMapping("/json")
    @ResponseBody
    public String postJson(@RequestBody User user) {
    	User user1=user;
        kafkaTemplate.send(JSON_TOPIC,user1);
        System.out.println("json message Published successfully");
        return "json message Published successfully";
    }
    
    @GetMapping("/string/{message}")
    @ResponseBody
    public String postString(@PathVariable("message") final String message) {
    	stringKafkaTemplate.send(STRING_TOPIC,message);
    	System.out.println("string message published successfully");
    	return "string message published successfully";
    }
    
    
    
    //for testing purpose
    @RequestMapping("/show")
    public String show(){
    	System.out.println("Show is working");
    	return "show is workimg";
    }
}